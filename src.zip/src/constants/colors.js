export default colors = {
  title: "#00c",
  button: "#099",
  messageBoard: "#333",
};
